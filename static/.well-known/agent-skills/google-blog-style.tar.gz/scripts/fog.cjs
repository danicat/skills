#!/usr/bin/env node
/**
 * Copyright 2026 Daniela Petruzalek
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * Calculates the Gunning Fog Index for a given text file.
 * Formula: 0.4 * ( (words / sentences) + 100 * (complexWords / words) )
 */

const fs = require('fs');

if (process.argv.length < 3) {
  console.error("Usage: node fog.js <filename>");
  process.exit(1);
}

const filename = process.argv[2];

try {
  const text = fs.readFileSync(filename, 'utf8');

  // Sentence Counting: simple punctuation check
  const sentences = (text.match(/[.!?]+/g) || []).length || 1;

  // Word Counting: remove punctuation, then split on whitespace.
  const cleanText = text.replace(/[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]/g, '');
  const words = cleanText.split(/\s+/).filter(w => w.length > 0);
  const wordCount = words.length;

  if (wordCount === 0) {
    console.log("Gunning Fog Index: 0 (No words found)");
    process.exit(0);
  }

  // Complex Words: 3+ syllables
  // Syllable counting: counts [aeiouy]+ vowel groups.
  const complexWordCount = words.filter(w => {
    const vowelGroups = w.match(/[aeiouy]+/gi);
    const syllables = vowelGroups ? vowelGroups.length : 1; // Default to 1 if no vowels
    return syllables >= 3;
  }).length;

  const avgSentenceLength = wordCount / sentences;
  const percentComplexWords = (complexWordCount / wordCount) * 100;

  const fogIndex = 0.4 * (avgSentenceLength + percentComplexWords);

  console.log(`Gunning Fog Index: ${fogIndex.toFixed(2)}`);

  // Readability classification thresholds
  // >= 18: Hard to Read
  // >= 13: Professional
  // >= 9: General
  // < 9: Simplistic
  if (fogIndex >= 18) {
     console.log("Readability: Hard to Read (Try shortening sentences)");
  } else if (fogIndex >= 13) {
     console.log("Readability: Professional Audiences (Acceptable for technical docs)");
  } else if (fogIndex >= 9) {
     console.log("Readability: General Audiences (Ideal)");
  } else {
     console.log("Readability: Simplistic");
  }

} catch (err) {
  console.error(`Error reading file: ${err.message}`);
  process.exit(1);
}
