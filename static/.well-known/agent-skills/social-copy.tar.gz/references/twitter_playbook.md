# Twitter / X Technical Copy Playbook

Comprehensive guide for writing high-performing developer, engineering, and open-source posts and threads on X (formerly Twitter).

---

## 1. Algorithm Mechanics & Engagement Multipliers

X's ranking engine utilizes transformer embeddings and graph clusters that reward high-signal intellectual engagement, dwell time, and permanent reference value.

### Algorithmic Weight Multipliers
- **Dwell Time & Reading Seconds:** Core ranking factor in the For You algorithm. Long-form posts that keep users reading directly multiply feed reach.
- **Bookmarks (~10x–13x over Likes):** The most critical signal for evergreen technical posts. Bookmarks signal "permanent reference utility."
- **Reposts / Retweets (~20x):** Primary viral amplifier pushing content into secondary timelines.
- **Quote Tweets (~15x):** Strong signal of thoughtful discussion and debate.
- **Replies (~13.5x):** Active conversations with back-and-forth interactions trigger massive distribution boosts.
- **Expand Post Clicks (`Show more`):** Strong implicit positive signal indicating the hook successfully converted into active reading.
- **Likes (1x):** Baseline low-effort signal.

### The Rise of Native Long-Form Posts, Visual Product Drops & X Articles
- **Long-Form (800–2,500 characters):** The highest-performing format on X for technical breakdowns, engineering changelogs, and case studies. It captures maximum dwell time, generates high bookmark ratios, and eliminates thread drop-off.
- **No Link Penalty for Native Posts:** Platform leadership confirmed that posts containing outbound URLs are not algorithmically penalized if accompanied by substantive native text and commentary (avoiding "lazy linking").
- **Visual Demos & Screenshots Drive Discussion and Clicks:** Attaching native visual proof (UI screenshots, architecture diagrams, terminal recordings, or live product demo clips) significantly increases feed reach, multiples reply depth (`3x+` over text-only posts), and accelerates outbound link click-throughs on launch announcements.

### Hashtag Consensus (0-Hashtags Rule)
- **Hashtags are essentially obsolete for organic reach on X.** The algorithm indexes text via semantic NLP and embeddings.
- Using 3+ hashtags triggers spam dampeners and looks amateurish. Use **0 hashtags** (or max 1 if participating in a recognized live event/conference).

### Publishing Cadence, Stream Velocity & Builder Windows
- **Early Engagement Velocity:** X operates on a short `1–3 hour` decay horizon and heavily weights engagement signals (likes, reposts, bookmarks, and replies) that occur in the first 15–30 minutes after publishing.
- **The 2-to-3 Hour Spacing Rule & Multi-Post Launch Velocity:** Unlike long-horizon feeds (LinkedIn) that penalize multiple posts on the same day, X rewards multi-post launch days when standalone broadcasts are separated by at least **2 to 3 hours**. Properly spaced launch sequences compound daily reach and outbound traffic, whereas rapid unthreaded clustering (multiple standalone tweets in minutes) splits early velocity.
- **Developer Exploration & Weekend Builder Windows:** Hands-on open-source demos, shipping logs, and high-leverage productivity showcases perform strongly during both mid-week windows and **weekend builder windows**, when corporate feed noise drops and developers actively explore new tools and repos.
- **Threads vs. Clustered Standalone Posts:** When publishing multiple related thoughts in the same sitting (under 2 hours apart), package them as a connected **Thread** so all interaction signals aggregate into the parent post rather than competing against each other.

---

## 2. Formatting & Post Ergonomics

### The Above-the-Fold Law (< 240–280 Characters)
- The timeline preview truncates copy at approx. **240–280 characters** (or 3–4 lines) with a `Show more` button.
- Deliver the core hook, metric, and tension before the truncation point.

### Format Types & Constraints
- **Long-Form Post (Recommended, 800–2,500 characters):** Complete standalone engineering breakdown with clean section headers, bulleted changelogs, and direct links.
- **Micro-Thread (3–5 tweets):** High retention, low drop-off. Best for step-by-step visual tutorials.
- **Single Tweet (180–260 characters):** Best for punchy releases, hot takes, quick tips, and single benchmark charts.

---

## 3. High-Converting Hook Archetypes

1. **The Benchmark / Metric Hook:**
   > *"How we dropped our Docker build times from 14 minutes to 38 seconds by changing one multi-stage cache flag:"*
2. **The Production Post-Mortem Hook:**
   > *"We accidentally leaked $14,000 in OpenAI API credits overnight.*
   >
   > *Here is the 1-line async retry bug that caused an infinite execution loop (and how to prevent it):"*
3. **The Architectural Philosophy Hook:**
   > *"Stop fighting the harness: As models get smarter, they get better at escaping sandboxes and bypassing rigid hooks.*
   >
   > *Here is the 'educative' tooling paradigm we switched to:"*

---

## 4. Plug-and-Play Templates

### Template A: Technical Case Study & Release (Long-Form Post)
```text
[Hook < 240 chars: Tension / Discovery / Sensation]

THE CHANGELOG:
• [Project 1]: [Key upgrade & 1-line impact]
• [Project 2]: [Key upgrade & 1-line impact]
• [Project 3]: [Key upgrade & 1-line impact]

THE ARCHITECTURAL LESSON: [Core Realization]
[2-3 paragraphs explaining the failure mode, the insight, and why traditional methods broke]

THE SOLUTION:
1. [Principle 1]
2. [Principle 2]
3. [Principle 3]

[Direct Links to repos/posts]
```
