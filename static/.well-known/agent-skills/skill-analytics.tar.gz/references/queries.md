# Skill analytics SQL query cookbook

All SQL recipes below run directly against `skill_analytics.db` using `uv run scripts/analyze.py query "<SQL>"`. Use these queries for portfolio tuning, description refinement, and catalog gap discovery.

---

## 1. Idle always-in-prompt skills audit (zero activations)

Identifies built-in, plugin, and globally installed skills that consume system-prompt tokens on every turn (`is_always_in_prompt = 1`) without production activations, showing both uncached exposure and Gemini 4 90% cache-adjusted token overhead (`cache_adjusted_tax_tokens`):

```sql
SELECT
    skill_name,
    source_tier,
    source_origin,
    tier1_tokens_est,
    cumulative_prompt_tax_tokens,
    cache_adjusted_tax_tokens,
    roi_recommendation
FROM v_skill_roi
WHERE is_always_in_prompt = 1
  AND total_activations = 0
  AND script_runs = 0
ORDER BY tier1_tokens_est DESC, skill_name ASC;
```

---

## 2. High-demand JIT skills to promote to global scope

Finds catalog skills loaded often on-demand (`PROMOTE_TO_GLOBAL`) that are not yet installed globally:

```sql
SELECT
    skill_name,
    category,
    total_activations,
    resource_reads,
    script_runs,
    conversations_used,
    conversation_reach_pct || '%' AS reach_pct,
    last_used_at
FROM v_skill_roi
WHERE is_always_in_prompt = 0
  AND total_activations >= 5
ORDER BY total_activations DESC, conversations_used DESC;
```

---

## 3. Trigger attribution audit (manual overrides vs. autonomous match)

Pinpoints skills that users invoke manually (`::skill`, `//skill`, or `/skill`) because agents miss their frontmatter descriptions (`NEEDS_DESCRIPTION_TUNING` or `WEAK_AUTONOMOUS_TRIGGER`):

```sql
SELECT
    skill_name,
    source_tier,
    total_activations,
    autonomous_activations,
    explicit_activations,
    autonomous_share_pct || '%' AS auto_pct,
    trigger_health
FROM v_trigger_attribution
WHERE total_activations > 0
ORDER BY explicit_activations DESC, total_activations DESC;
```

---

## 4. Progressive disclosure depth (root loads vs. reference and script use)

Measures how deeply agents engage with each skill's companion `references/` and `scripts/` after loading `SKILL.md`:

```sql
SELECT
    skill_name,
    source_tier,
    total_activations,
    resource_reads,
    script_runs,
    ROUND(1.0 * (resource_reads + script_runs) / MAX(1, total_activations), 2) AS tier3_depth_ratio
FROM v_skill_roi
WHERE total_activations > 0 OR resource_reads > 0 OR script_runs > 0
ORDER BY (resource_reads + script_runs) DESC, total_activations DESC
LIMIT 20;
```

---

## 5. Catalog gap discovery (unmet `kungfu find` and `:?` searches)

Lists search queries issued through `kungfu find` or `:?` that did not result in a subsequent skill load within 12 steps:

```sql
SELECT
    search_query,
    invocation_kind,
    search_count,
    led_to_load_count,
    last_searched_at
FROM v_search_gaps
WHERE led_to_load_count = 0
ORDER BY search_count DESC, last_searched_at DESC;
```

---

## 6. User prompt notation adoption over time (`::skill` vs. `//skill` vs. `:?`)

Tracks user prompt shortcut notations across conversations:

```sql
SELECT
    substr(step_created_at, 1, 10) AS day,
    notation_type,
    COUNT(*) AS notation_count,
    COUNT(DISTINCT conversation_id) AS conversations
FROM skill_events
WHERE invocation_kind = 'user_notation'
  AND is_self_test = 0
GROUP BY day, notation_type
ORDER BY day DESC, notation_count DESC;
```

---

## 7. Multi-skill conversation workflows (co-occurrence per conversation)

Identifies conversations that activated multiple distinct skills, showing which skills combine in complex tasks:

```sql
SELECT
    c.conversation_id,
    c.title,
    COUNT(DISTINCT e.target_skill) AS distinct_skills_used,
    GROUP_CONCAT(DISTINCT e.target_skill) AS skills_list,
    c.total_steps
FROM conversations c
JOIN skill_events e ON e.conversation_id = c.conversation_id
WHERE e.is_self_test = 0
  AND e.target_skill IS NOT NULL
  AND instr(e.target_skill, ',') = 0
GROUP BY c.conversation_id
HAVING COUNT(DISTINCT e.target_skill) >= 2
ORDER BY distinct_skills_used DESC, c.total_steps DESC
LIMIT 20;
```
